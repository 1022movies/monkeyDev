# libstdc++
`Xcode 10`之后删除的`libstdc++`库

1. 先下载下来这个项目，然后打开终端`cd`到`libstdc--master`文件夹；
2. 如果你使用的是 Xcode 10，则将`install-xcode_10.sh`拖到终端中执行即可；
3. Xcode 11 之后的版本则将`install-xcode_11+.sh`拖到终端中执行。
